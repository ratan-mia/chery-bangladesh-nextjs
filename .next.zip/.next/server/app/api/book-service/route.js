(()=>{var e={};e.id=87,e.ids=[87],e.modules={3295:e=>{"use strict";e.exports=require("next/dist/server/app-render/after-task-async-storage.external.js")},10846:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},21820:e=>{"use strict";e.exports=require("os")},27910:e=>{"use strict";e.exports=require("stream")},28354:e=>{"use strict";e.exports=require("util")},29021:e=>{"use strict";e.exports=require("fs")},29294:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-async-storage.external.js")},33873:e=>{"use strict";e.exports=require("path")},34631:e=>{"use strict";e.exports=require("tls")},37366:e=>{"use strict";e.exports=require("dns")},44775:(e,i,t)=>{"use strict";t.r(i),t.d(i,{patchFetch:()=>u,routeModule:()=>c,serverHooks:()=>h,workAsyncStorage:()=>p,workUnitAsyncStorage:()=>v});var a={};t.r(a),t.d(a,{POST:()=>n});var r=t(96559),o=t(48088),s=t(37719),d=t(32190),l=t(49526);async function n(e){try{let i=await e.json(),t=l.createTransport({service:"gmail",auth:{user:process.env.GMAIL_USER,pass:process.env.GMAIL_APP_PASSWORD}}),a=new Date(i.preferredDate).toLocaleDateString("en-US",{year:"numeric",month:"long",day:"numeric"});return await t.sendMail({from:`"Chery Service Booking" <${process.env.GMAIL_USER}>`,to:[i.adminEmail1,i.adminEmail2],subject:`New Service Booking: ${i.vehicleModel} - ${i.serviceType}`,html:`
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="utf-8">
        <title>New Service Booking</title>
        <style>
          body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            color: #333;
            margin: 0;
            padding: 0;
          }
          .container {
            max-width: 600px;
            margin: 0 auto;
            padding: 20px;
          }
          .header {
            background-color: #1a1a1a;
            padding: 20px;
            text-align: center;
          }
          .header img {
            max-width: 150px;
          }
          .content {
            padding: 20px;
            background-color: #f9f9f9;
          }
          h1 {
            color: #c20000;
            margin-top: 0;
            font-size: 24px;
          }
          .booking-details {
            background-color: #fff;
            border: 1px solid #ddd;
            padding: 15px;
            margin-bottom: 20px;
          }
          .booking-details h2 {
            margin-top: 0;
            color: #333;
            font-size: 18px;
            border-bottom: 1px solid #eee;
            padding-bottom: 10px;
          }
          .detail-row {
            display: flex;
            margin-bottom: 10px;
          }
          .detail-label {
            width: 40%;
            font-weight: bold;
            color: #555;
          }
          .detail-value {
            width: 60%;
          }
          .footer {
            text-align: center;
            padding: 20px;
            font-size: 12px;
            color: #777;
          }
          .priority {
            display: inline-block;
            padding: 5px 10px;
            background-color: #c20000;
            color: white;
            font-weight: bold;
            border-radius: 3px;
            margin-bottom: 20px;
          }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="header">
            <img src="https://cherybd.com/logo.png" alt="Chery Bangladesh Logo">
          </div>
          <div class="content">
            <h1>New Service Booking</h1>
            <div class="priority">ADMIN NOTIFICATION</div>
            <p>A new service booking has been submitted. Please review the details below and contact the customer to confirm their appointment.</p>
            
            <div class="booking-details">
              <h2>Vehicle Information</h2>
              <div class="detail-row">
                <div class="detail-label">Vehicle Model:</div>
                <div class="detail-value">${i.vehicleModel}</div>
              </div>
              <div class="detail-row">
                <div class="detail-label">Registration Number:</div>
                <div class="detail-value">${i.vehicleRegNumber}</div>
              </div>
            </div>
            
            <div class="booking-details">
              <h2>Service Details</h2>
              <div class="detail-row">
                <div class="detail-label">Service Type:</div>
                <div class="detail-value">${i.serviceType}</div>
              </div>
              <div class="detail-row">
                <div class="detail-label">Preferred Date:</div>
                <div class="detail-value">${a}</div>
              </div>
              <div class="detail-row">
                <div class="detail-label">Preferred Time:</div>
                <div class="detail-value">${i.preferredTime}</div>
              </div>
              <div class="detail-row">
                <div class="detail-label">Additional Notes:</div>
                <div class="detail-value">${i.notes||"No additional notes provided"}</div>
              </div>
            </div>
            
            <div class="booking-details">
              <h2>Customer Information</h2>
              <div class="detail-row">
                <div class="detail-label">Name:</div>
                <div class="detail-value">${i.name}</div>
              </div>
              <div class="detail-row">
                <div class="detail-label">Email:</div>
                <div class="detail-value">${i.email}</div>
              </div>
              <div class="detail-row">
                <div class="detail-label">Phone:</div>
                <div class="detail-value">${i.contactNumber}</div>
              </div>
            </div>
            
            <p>Please schedule this appointment in the service calendar and contact the customer to confirm the booking.</p>
          </div>
          <div class="footer">
            <p>This is an automated message from the Chery Bangladesh Service Booking System. Please do not reply to this email.</p>
            <p>&copy; ${new Date().getFullYear()} Chery Bangladesh. All rights reserved.</p>
          </div>
        </div>
      </body>
      </html>
    `}),await t.sendMail({from:`"Chery Bangladesh" <${process.env.GMAIL_USER}>`,to:i.email,subject:"Your Chery Service Booking Confirmation",html:`
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="utf-8">
        <title>Service Booking Confirmation</title>
        <style>
          body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            color: #333;
            margin: 0;
            padding: 0;
          }
          .container {
            max-width: 600px;
            margin: 0 auto;
            padding: 20px;
          }
          .header {
            background-color: #1a1a1a;
            padding: 20px;
            text-align: center;
          }
          .header img {
            max-width: 150px;
          }
          .content {
            padding: 20px;
            background-color: #f9f9f9;
          }
          h1 {
            color: #c20000;
            margin-top: 0;
            font-size: 24px;
          }
          .booking-details {
            background-color: #fff;
            border: 1px solid #ddd;
            padding: 15px;
            margin-bottom: 20px;
          }
          .booking-details h2 {
            margin-top: 0;
            color: #333;
            font-size: 18px;
            border-bottom: 1px solid #eee;
            padding-bottom: 10px;
          }
          .detail-row {
            display: flex;
            margin-bottom: 10px;
          }
          .detail-label {
            width: 40%;
            font-weight: bold;
            color: #555;
          }
          .detail-value {
            width: 60%;
          }
          .footer {
            text-align: center;
            padding: 20px;
            font-size: 12px;
            color: #777;
          }
          .confirmation-box {
            background-color: #dff0d8;
            border: 1px solid #d6e9c6;
            color: #3c763d;
            padding: 15px;
            margin-bottom: 20px;
            text-align: center;
          }
          .confirmation-number {
            font-size: 18px;
            font-weight: bold;
            color: #c20000;
          }
          .what-next {
            background-color: #f5f5f5;
            border: 1px solid #ddd;
            padding: 15px;
            margin-top: 20px;
          }
          .what-next h3 {
            margin-top: 0;
            color: #333;
          }
          .what-next ul {
            padding-left: 20px;
          }
          .contact-info {
            margin-top: 20px;
            background-color: #eee;
            padding: 15px;
            text-align: center;
          }
          .social-links {
            text-align: center;
            margin-top: 15px;
          }
          .social-links a {
            display: inline-block;
            margin: 0 5px;
            text-decoration: none;
          }
          .button {
            display: inline-block;
            padding: 10px 20px;
            background-color: #c20000;
            color: white;
            text-decoration: none;
            text-align: center;
            border-radius: 3px;
            font-weight: bold;
            margin-top: 15px;
          }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="header">
            <img src="https://cherybd.com/logo.png" alt="Chery Bangladesh Logo">
          </div>
          <div class="content">
            <h1>Your Service Booking is Confirmed!</h1>
            
            <div class="confirmation-box">
              <p>Thank you for choosing Chery Bangladesh for your vehicle service needs.</p>
              <p>Your booking has been received and is being processed.</p>
              <p>Confirmation Number: <span class="confirmation-number">${function(e){let i=new Date().toISOString().replace(/[^0-9]/g,"").slice(0,8),t=Math.floor(1e4*Math.random()).toString().padStart(4,"0"),a=e.name.split(" ").map(e=>e[0]).join("").toUpperCase();return`SRV-${i.slice(2)}-${t}-${a}`}(i)}</span></p>
            </div>
            
            <div class="booking-details">
              <h2>Booking Details</h2>
              <div class="detail-row">
                <div class="detail-label">Vehicle Model:</div>
                <div class="detail-value">${i.vehicleModel}</div>
              </div>
              <div class="detail-row">
                <div class="detail-label">Registration Number:</div>
                <div class="detail-value">${i.vehicleRegNumber}</div>
              </div>
              <div class="detail-row">
                <div class="detail-label">Service Type:</div>
                <div class="detail-value">${i.serviceType}</div>
              </div>
              <div class="detail-row">
                <div class="detail-label">Scheduled Date:</div>
                <div class="detail-value">${a}</div>
              </div>
              <div class="detail-row">
                <div class="detail-label">Scheduled Time:</div>
                <div class="detail-value">${i.preferredTime}</div>
              </div>
            </div>
            
            <div class="what-next">
              <h3>What Happens Next?</h3>
              <ul>
                <li>Our service team will call you within 2 hours to confirm your appointment.</li>
                <li>You'll receive a reminder email one day before your scheduled service.</li>
                <li>Please bring your vehicle registration documents when you visit.</li>
                <li>Our service center offers complimentary refreshments and Wi-Fi while you wait.</li>
              </ul>
            </div>
            
            <div class="what-next">
              <h3>Service Center Location</h3>
              <p>Chery Bangladesh Service Center<br>
              123 Service Road, Dhaka<br>
              Bangladesh</p>
              
              <a href="https://maps.google.com/?q=Chery+Bangladesh+Service+Center" class="button">View on Map</a>
            </div>
            
            <div class="contact-info">
              <h3>Need to Make Changes?</h3>
              <p>If you need to reschedule or have any questions, please contact our service center:</p>
              <p>Phone: 09639119977<br>
              Email: service@cherybd.com</p>
            </div>
            
            <div class="social-links">
              <p>Follow us for updates and maintenance tips:</p>
              <a href="https://facebook.com/cherybangladesh">Facebook</a> |
              <a href="https://instagram.com/cherybangladesh">Instagram</a> |
              <a href="https://youtube.com/cherybangladesh">YouTube</a>
            </div>
          </div>
          <div class="footer">
            <p>Thank you for choosing Chery Bangladesh for your service needs.</p>
            <p>&copy; ${new Date().getFullYear()} Chery Bangladesh. All rights reserved.</p>
          </div>
        </div>
      </body>
      </html>
    `}),d.NextResponse.json({success:!0,message:"Booking successful. Confirmation emails have been sent."})}catch(e){return console.error("Error processing booking:",e),d.NextResponse.json({success:!1,message:"Failed to process booking request"},{status:500})}}let c=new r.AppRouteRouteModule({definition:{kind:o.RouteKind.APP_ROUTE,page:"/api/book-service/route",pathname:"/api/book-service",filename:"route",bundlePath:"app/api/book-service/route"},resolvedPagePath:"D:\\Projects\\chery-bangladesh-nextjs\\src\\app\\api\\book-service\\route.js",nextConfigOutput:"export",userland:a}),{workAsyncStorage:p,workUnitAsyncStorage:v,serverHooks:h}=c;function u(){return(0,s.patchFetch)({workAsyncStorage:p,workUnitAsyncStorage:v})}},44870:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},55511:e=>{"use strict";e.exports=require("crypto")},55591:e=>{"use strict";e.exports=require("https")},63033:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-unit-async-storage.external.js")},74075:e=>{"use strict";e.exports=require("zlib")},78335:()=>{},79551:e=>{"use strict";e.exports=require("url")},79646:e=>{"use strict";e.exports=require("child_process")},81630:e=>{"use strict";e.exports=require("http")},91645:e=>{"use strict";e.exports=require("net")},94735:e=>{"use strict";e.exports=require("events")},96487:()=>{}};var i=require("../../../webpack-runtime.js");i.C(e);var t=e=>i(i.s=e),a=i.X(0,[447,580,526],()=>t(44775));module.exports=a})();