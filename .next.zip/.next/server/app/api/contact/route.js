(()=>{var e={};e.id=746,e.ids=[746],e.modules={3295:e=>{"use strict";e.exports=require("next/dist/server/app-render/after-task-async-storage.external.js")},10846:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},21820:e=>{"use strict";e.exports=require("os")},27910:e=>{"use strict";e.exports=require("stream")},28354:e=>{"use strict";e.exports=require("util")},29021:e=>{"use strict";e.exports=require("fs")},29294:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-async-storage.external.js")},33873:e=>{"use strict";e.exports=require("path")},34631:e=>{"use strict";e.exports=require("tls")},37366:e=>{"use strict";e.exports=require("dns")},44870:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},55511:e=>{"use strict";e.exports=require("crypto")},55591:e=>{"use strict";e.exports=require("https")},63033:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-unit-async-storage.external.js")},74075:e=>{"use strict";e.exports=require("zlib")},78335:()=>{},78697:(e,t,o)=>{"use strict";o.r(t),o.d(t,{patchFetch:()=>h,routeModule:()=>p,serverHooks:()=>m,workAsyncStorage:()=>c,workUnitAsyncStorage:()=>u});var r={};o.r(r),o.d(r,{POST:()=>d});var i=o(96559),s=o(48088),n=o(37719),a=o(32190),l=o(49526);async function d(e){try{let t=await e.json();if(!t.name||!t.email||!t.phone||!t.subject||!t.message)return a.NextResponse.json({error:"Missing required fields"},{status:400});if(!/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i.test(t.email))return a.NextResponse.json({error:"Invalid email address"},{status:400});if(!/^\+?[0-9\s-()]{8,20}$/.test(t.phone))return a.NextResponse.json({error:"Invalid phone number"},{status:400});let o=l.createTransport({service:"gmail",auth:{user:process.env.GMAIL_USER,pass:process.env.GMAIL_APP_PASSWORD}});console.log("Attempting to verify SMTP connection...");try{await o.verify(),console.log("SMTP connection verified successfully")}catch(e){return console.error("SMTP connection failed:",e),a.NextResponse.json({error:"Email server connection failed. Please try again later."},{status:500})}let r=`INQ-${Date.now().toString(36).toUpperCase()}`,i=`
    <!DOCTYPE html>
    <html lang="en">
    <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>New Contact Form Submission</title>
    </head>
    <body style="font-family: Arial, Helvetica, sans-serif; line-height: 1.6; color: #333333; max-width: 650px; margin: 0 auto; padding: 20px; background-color: #f5f5f5;">
      <div style="background-color: #ffffff; border-radius: 8px; box-shadow: 0 2px 5px rgba(0,0,0,0.1); padding: 30px;">
        <div style="text-align: center; margin-bottom: 30px; border-bottom: 1px solid #eeeeee; padding-bottom: 20px;">
          <!-- Logo would go here in production -->
          <h1 style="color: #b29980; font-size: 24px; margin-top: 15px; margin-bottom: 5px;">New Website Inquiry</h1>
          <p style="color: #666666;">A potential customer has reached out via the contact form</p>
        </div>
  
        <div style="margin-bottom: 25px;">
          <h2 style="color: #333333; font-size: 18px; border-bottom: 1px solid #eeeeee; padding-bottom: 10px;">Customer Information</h2>
          
          <div style="margin-bottom: 10px; display: flex;">
            <div style="font-weight: bold; width: 120px; color: #555555;">Name:</div>
            <div>${t.name}</div>
          </div>
          
          <div style="margin-bottom: 10px; display: flex;">
            <div style="font-weight: bold; width: 120px; color: #555555;">Email:</div>
            <div><a href="mailto:${t.email}" style="color: #b29980; text-decoration: none;">${t.email}</a></div>
          </div>
          
          <div style="margin-bottom: 10px; display: flex;">
            <div style="font-weight: bold; width: 120px; color: #555555;">Phone:</div>
            <div><a href="tel:${t.phone}" style="color: #b29980; text-decoration: none;">${t.phone}</a></div>
          </div>
          
          ${t.model?`
          <div style="margin-bottom: 10px; display: flex;">
            <div style="font-weight: bold; width: 120px; color: #555555;">Vehicle Model:</div>
            <div>${t.model}</div>
          </div>
          `:""}
          
          <div style="margin-bottom: 10px; display: flex;">
            <div style="font-weight: bold; width: 120px; color: #555555;">Subject:</div>
            <div>${t.subject}</div>
          </div>
        </div>
  
        <div style="margin-bottom: 25px;">
          <h2 style="color: #333333; font-size: 18px; border-bottom: 1px solid #eeeeee; padding-bottom: 10px;">Customer Message</h2>
          <div style="background-color: #f9f9f9; border-left: 4px solid #b29980; padding: 15px; border-radius: 4px; margin-top: 15px;">
            <div style="white-space: pre-line;">${t.message.replace(/\n/g,"<br>")}</div>
          </div>
        </div>
  
        <div style="background-color: #f0f0f0; padding: 15px; border-radius: 4px; margin-top: 25px; font-size: 14px; color: #666666;">
          <p style="margin: 0 0 8px 0;"><strong>Submission Time:</strong> ${new Date().toLocaleString("en-US",{timeZone:"Asia/Dhaka"})}</p>
          <p style="margin: 0 0 8px 0;"><strong>Reference:</strong> ${r}</p>
        </div>
  
        <div style="margin-top: 30px; padding-top: 20px; border-top: 1px solid #eeeeee; font-size: 12px; color: #999999; text-align: center;">
          <p>This is an automated email sent from the Chery Bangladesh website contact form.</p>
          <p>\xa9 ${new Date().getFullYear()} Chery Bangladesh. All rights reserved.</p>
        </div>
      </div>
    </body>
    </html>
    `,s=`
    <!DOCTYPE html>
    <html lang="en">
    <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>Thank You for Contacting Chery Bangladesh</title>
    </head>
    <body style="font-family: Arial, Helvetica, sans-serif; line-height: 1.6; color: #333333; max-width: 650px; margin: 0 auto; padding: 20px; background-color: #f5f5f5;">
      <div style="background-color: #ffffff; border-radius: 8px; box-shadow: 0 2px 5px rgba(0,0,0,0.1); padding: 30px;">
        <div style="text-align: center; margin-bottom: 30px;">
          <!-- Logo would go here in production -->
          <h1 style="color: #b29980; font-size: 24px; margin-top: 20px;">Thank You for Contacting Us</h1>
        </div>
  
        <div style="margin-bottom: 30px;">
          <p>Dear ${t.name},</p>
          
          <p>Thank you for reaching out to Chery Bangladesh. We have received your inquiry regarding <strong>"${t.subject}"</strong> and a member of our team will get back to you shortly.</p>
          
          <div style="background-color: #f8f4f0; border-left: 4px solid #b29980; padding: 15px; border-radius: 4px; margin: 20px 0;">
            <p style="margin-top: 0;">Your request has been assigned a reference number: <strong>${r}</strong></p>
            <p style="margin-bottom: 0;">Please save this for future correspondence.</p>
          </div>
          
          ${t.model?`
          <p>We appreciate your interest in the <strong>${t.model}</strong> model. Our team is excited to provide you with all the information you need.</p>
          `:""}
          
          <p>Here's what you can expect next:</p>
          <ul>
            <li>A dedicated representative will review your inquiry</li>
            <li>You will receive a personal response within 24-48 business hours</li>
            <li>We may contact you via phone for additional information</li>
          </ul>
        </div>
  
        <div style="background-color: #f5f5f5; padding: 20px; border-radius: 4px; margin-top: 20px; text-align: center;">
          <h3 style="color: #333333; margin-top: 0;">Need Immediate Assistance?</h3>
          <p>Call us: <a href="tel:09639119977" style="color: #b29980; text-decoration: none;">09639119977</a></p>
          <p>Email: <a href="mailto:info@cherybd.com" style="color: #b29980; text-decoration: none;">info@cherybd.com</a></p>
          <p>Visit our showroom: 206/1-207/1 Bir Uttam Mir Shawkat Sarak<br>Tejgaon Gulshan Link Road, Dhaka</p>
        </div>
        
        <div style="text-align: center; margin-top: 30px;">
          <p>Connect with us:</p>
          <div>
            <a href="https://www.facebook.com/CheryBDofficial" style="display: inline-block; background-color: #f0f0f0; width: 32px; height: 32px; line-height: 32px; text-align: center; border-radius: 50%; margin: 0 5px; text-decoration: none; color: #333333;" title="Facebook">FB</a>
            <a href="https://www.linkedin.com/company/chery-bangladesh/" style="display: inline-block; background-color: #f0f0f0; width: 32px; height: 32px; line-height: 32px; text-align: center; border-radius: 50%; margin: 0 5px; text-decoration: none; color: #333333;" title="LinkedIn">LI</a>
            <a href="https://www.youtube.com/@cherybangladesh" style="display: inline-block; background-color: #f0f0f0; width: 32px; height: 32px; line-height: 32px; text-align: center; border-radius: 50%; margin: 0 5px; text-decoration: none; color: #333333;" title="YouTube">YT</a>
          </div>
        </div>
  
        <div style="margin-top: 30px; padding-top: 20px; border-top: 1px solid #eeeeee; font-size: 12px; color: #999999; text-align: center;">
          <p>This is an automated response. Please do not reply to this email.</p>
          <p>\xa9 ${new Date().getFullYear()} Chery Bangladesh. All rights reserved.</p>
          <p>Your inquiry was received on ${new Date().toLocaleString("en-US",{timeZone:"Asia/Dhaka"})}</p>
        </div>
      </div>
    </body>
    </html>
    `;console.log("Sending email to administrators...");try{let e=await o.sendMail({from:`"Chery Bangladesh Website" <${process.env.GMAIL_USER}>`,to:["info@cherybd.com","ratan.mia@continental-motor.com"],subject:`Website Contact: ${t.subject}`,html:i,replyTo:t.email});console.log("Admin email sent successfully:",e.messageId)}catch(e){throw console.error("Error sending admin email:",e),Error("Failed to send notification to admins")}console.log("Sending confirmation to customer...");try{let e=await o.sendMail({from:`"Chery Bangladesh" <${process.env.GMAIL_USER}>`,to:t.email,subject:"Thank You for Contacting Chery Bangladesh",html:s});console.log("Customer email sent successfully:",e.messageId)}catch(e){console.error("Error sending customer email:",e)}return a.NextResponse.json({message:"Your message has been sent successfully. We will contact you soon."},{status:200})}catch(e){return console.error("Error in contact form submission:",e),a.NextResponse.json({error:"Failed to send your message. Please try again later."},{status:500})}}let p=new i.AppRouteRouteModule({definition:{kind:s.RouteKind.APP_ROUTE,page:"/api/contact/route",pathname:"/api/contact",filename:"route",bundlePath:"app/api/contact/route"},resolvedPagePath:"D:\\Projects\\chery-bangladesh-nextjs\\src\\app\\api\\contact\\route.js",nextConfigOutput:"export",userland:r}),{workAsyncStorage:c,workUnitAsyncStorage:u,serverHooks:m}=p;function h(){return(0,n.patchFetch)({workAsyncStorage:c,workUnitAsyncStorage:u})}},79551:e=>{"use strict";e.exports=require("url")},79646:e=>{"use strict";e.exports=require("child_process")},81630:e=>{"use strict";e.exports=require("http")},91645:e=>{"use strict";e.exports=require("net")},94735:e=>{"use strict";e.exports=require("events")},96487:()=>{}};var t=require("../../../webpack-runtime.js");t.C(e);var o=e=>t(t.s=e),r=t.X(0,[447,580,526],()=>o(78697));module.exports=r})();