(()=>{var e={};e.id=414,e.ids=[414],e.modules={3295:e=>{"use strict";e.exports=require("next/dist/server/app-render/after-task-async-storage.external.js")},10846:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},21820:e=>{"use strict";e.exports=require("os")},26765:(e,i,t)=>{"use strict";t.r(i),t.d(i,{patchFetch:()=>w,routeModule:()=>f,serverHooks:()=>b,workAsyncStorage:()=>y,workUnitAsyncStorage:()=>x});var a={};t.r(a),t.d(a,{POST:()=>g});var s=t(96559),r=t(48088),o=t(37719),d=t(32190),l=t(49526);let n=require("mongoose");var c=t.n(n);let p=new(c()).Schema({assistanceType:{type:String,required:[!0,"Please specify the type of assistance needed"],trim:!0},location:{type:String,required:[!0,"Please provide your current location"],trim:!0},description:{type:String,trim:!0},vehicleModel:{type:String,required:[!0,"Please provide the vehicle model"],trim:!0},vehicleRegNumber:{type:String,required:[!0,"Please provide the vehicle registration number"],trim:!0},name:{type:String,required:[!0,"Please provide your name"],trim:!0},email:{type:String,required:[!0,"Please provide your email"],trim:!0,match:[/^\S+@\S+\.\S+$/,"Please provide a valid email address"]},contactNumber:{type:String,required:[!0,"Please provide your contact number"],trim:!0},status:{type:String,enum:["pending","dispatched","completed","cancelled"],default:"pending"},referenceNumber:{type:String,required:!0,unique:!0},dispatchedAt:{type:Date},estimatedArrivalTime:{type:Date},technicianName:{type:String,trim:!0},technicianContact:{type:String,trim:!0},resolutionNotes:{type:String,trim:!0},serviceProvidedAt:{type:Date},createdAt:{type:Date,default:Date.now},updatedAt:{type:Date,default:Date.now}});p.pre("save",function(e){this.updatedAt=Date.now(),e()});let u=c().models.AssistanceRequest||c().model("AssistanceRequest",p),m=process.env.MONGODB_URI;if(!m)throw Error("Please define the MONGODB_URI environment variable inside .env.local");let v=global.mongoose;async function h(){return v.conn||(v.promise||(v.promise=c().connect(m,{bufferCommands:!1}).then(e=>e)),v.conn=await v.promise),v.conn}async function g(e){try{var i,t;let a=await e.json(),s=function(e){let i=new Date().toISOString().replace(/[^0-9]/g,"").slice(0,12),t=Math.floor(1e4*Math.random()).toString().padStart(4,"0"),a=e.location.substring(0,3).toUpperCase().replace(/[^A-Z]/g,"X");return`RSA-${i}-${t}-${a}`}(a);await h();let r=await u.create({...a,referenceNumber:s,status:"pending",createdAt:new Date,updatedAt:new Date}),o=l.createTransport({service:"gmail",auth:{user:process.env.GMAIL_USER,pass:process.env.GMAIL_APP_PASSWORD}}),n=new Date().toLocaleString("en-US",{year:"numeric",month:"long",day:"numeric",hour:"2-digit",minute:"2-digit"});return await o.sendMail({from:`"Chery Roadside Assistance" <${process.env.GMAIL_USER}>`,to:[a.adminEmail1,a.adminEmail2],subject:`URGENT: Roadside Assistance Request - ${a.assistanceType}`,html:(i={...a,referenceNumber:s},`
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="utf-8">
        <title>URGENT: Roadside Assistance Request</title>
        <style>
          body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            color: #333;
            margin: 0;
            padding: 0;
          }
          .container {
            max-width: 600px;
            margin: 0 auto;
            padding: 20px;
          }
          .header {
            background-color: #c20000;
            padding: 20px;
            text-align: center;
          }
          .header img {
            max-width: 150px;
          }
          .urgent-banner {
            background-color: #ff0000;
            color: white;
            padding: 15px;
            text-align: center;
            font-size: 18px;
            font-weight: bold;
            margin-bottom: 20px;
          }
          .content {
            padding: 20px;
            background-color: #f9f9f9;
          }
          h1 {
            color: #c20000;
            margin-top: 0;
            font-size: 24px;
          }
          .request-details {
            background-color: #fff;
            border: 1px solid #ddd;
            padding: 15px;
            margin-bottom: 20px;
          }
          .request-details h2 {
            margin-top: 0;
            color: #333;
            font-size: 18px;
            border-bottom: 1px solid #eee;
            padding-bottom: 10px;
          }
          .detail-row {
            display: flex;
            margin-bottom: 10px;
          }
          .detail-label {
            width: 40%;
            font-weight: bold;
            color: #555;
          }
          .detail-value {
            width: 60%;
          }
          .footer {
            text-align: center;
            padding: 20px;
            font-size: 12px;
            color: #777;
          }
          .emergency {
            background-color: #fff0f0;
            border: 2px solid #ff0000;
            padding: 15px;
            margin-bottom: 20px;
          }
          .emergency h3 {
            color: #ff0000;
            margin-top: 0;
          }
          .map-link {
            display: inline-block;
            background-color: #4285F4;
            color: white;
            padding: 10px 20px;
            text-decoration: none;
            border-radius: 3px;
            font-weight: bold;
            margin-top: 10px;
          }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="header">
            <img src="https://cherybd.com/logo.png" alt="Chery Bangladesh Logo">
          </div>
          
          <div class="urgent-banner">
            URGENT: ROADSIDE ASSISTANCE REQUIRED
          </div>
          
          <div class="content">
            <h1>Emergency Assistance Request</h1>
            
            <div class="emergency">
              <h3>IMMEDIATE ACTION REQUIRED</h3>
              <p>A customer is stranded and requires urgent roadside assistance. Please dispatch the nearest technician immediately.</p>
              <p><strong>Reference Number:</strong> ${i.referenceNumber}</p>
              <p><strong>Request Time:</strong> ${n}</p>
            </div>
            
            <div class="request-details">
              <h2>Assistance Details</h2>
              <div class="detail-row">
                <div class="detail-label">Assistance Type:</div>
                <div class="detail-value">${i.assistanceType}</div>
              </div>
              <div class="detail-row">
                <div class="detail-label">Location:</div>
                <div class="detail-value">${i.location}</div>
              </div>
              <div class="detail-row">
                <div class="detail-label">Map:</div>
                <div class="detail-value">
                  <a href="https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(i.location)}" class="map-link" target="_blank">View on Google Maps</a>
                </div>
              </div>
              <div class="detail-row">
                <div class="detail-label">Problem Description:</div>
                <div class="detail-value">${i.description||"No additional description provided"}</div>
              </div>
            </div>
            
            <div class="request-details">
              <h2>Vehicle Information</h2>
              <div class="detail-row">
                <div class="detail-label">Vehicle Model:</div>
                <div class="detail-value">${i.vehicleModel}</div>
              </div>
              <div class="detail-row">
                <div class="detail-label">Registration Number:</div>
                <div class="detail-value">${i.vehicleRegNumber}</div>
              </div>
            </div>
            
            <div class="request-details">
              <h2>Customer Information</h2>
              <div class="detail-row">
                <div class="detail-label">Name:</div>
                <div class="detail-value">${i.name}</div>
              </div>
              <div class="detail-row">
                <div class="detail-label">Email:</div>
                <div class="detail-value">${i.email}</div>
              </div>
              <div class="detail-row">
                <div class="detail-label">Phone:</div>
                <div class="detail-value">${i.contactNumber}</div>
              </div>
            </div>
            
            <p>Please contact the customer immediately to confirm assistance is on the way and update the status in the system.</p>
          </div>
          <div class="footer">
            <p>This is an automated message from the Chery Bangladesh Roadside Assistance System.</p>
            <p>&copy; ${new Date().getFullYear()} Chery Bangladesh. All rights reserved.</p>
          </div>
        </div>
      </body>
      </html>
    `),priority:"high",headers:{"X-Priority":"1","X-MSMail-Priority":"High",Importance:"High"}}),await o.sendMail({from:`"Chery Bangladesh" <${process.env.GMAIL_USER}>`,to:a.email,subject:"Your Roadside Assistance Request Confirmation",html:(t={...a,referenceNumber:s},`
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="utf-8">
        <title>Roadside Assistance Confirmation</title>
        <style>
          body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            color: #333;
            margin: 0;
            padding: 0;
          }
          .container {
            max-width: 600px;
            margin: 0 auto;
            padding: 20px;
          }
          .header {
            background-color: #1a1a1a;
            padding: 20px;
            text-align: center;
          }
          .header img {
            max-width: 150px;
          }
          .content {
            padding: 20px;
            background-color: #f9f9f9;
          }
          h1 {
            color: #c20000;
            margin-top: 0;
            font-size: 24px;
          }
          .confirmation-box {
            background-color: #dff0d8;
            border: 1px solid #d6e9c6;
            color: #3c763d;
            padding: 15px;
            margin-bottom: 20px;
            text-align: center;
          }
          .reference-number {
            font-size: 18px;
            font-weight: bold;
            color: #c20000;
          }
          .request-details {
            background-color: #fff;
            border: 1px solid #ddd;
            padding: 15px;
            margin-bottom: 20px;
          }
          .request-details h2 {
            margin-top: 0;
            color: #333;
            font-size: 18px;
            border-bottom: 1px solid #eee;
            padding-bottom: 10px;
          }
          .detail-row {
            display: flex;
            margin-bottom: 10px;
          }
          .detail-label {
            width: 40%;
            font-weight: bold;
            color: #555;
          }
          .detail-value {
            width: 60%;
          }
          .footer {
            text-align: center;
            padding: 20px;
            font-size: 12px;
            color: #777;
          }
          .assistance-steps {
            background-color: #f5f5f5;
            border: 1px solid #ddd;
            padding: 15px;
            margin-top: 20px;
          }
          .assistance-steps h3 {
            margin-top: 0;
            color: #333;
          }
          .assistance-steps ol {
            padding-left: 20px;
          }
          .contact-info {
            margin-top: 20px;
            background-color: #eee;
            padding: 15px;
            text-align: center;
          }
          .emergency-number {
            font-size: 24px;
            font-weight: bold;
            color: #c20000;
            display: block;
            margin: 10px 0;
          }
          .tips-box {
            background-color: #f8f9fa;
            border: 1px solid #dee2e6;
            padding: 15px;
            margin-top: 20px;
          }
          .tips-box h3 {
            margin-top: 0;
            color: #333;
          }
          .tips-box ul {
            padding-left: 20px;
          }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="header">
            <img src="https://cherybd.com/logo.png" alt="Chery Bangladesh Logo">
          </div>
          <div class="content">
            <h1>Roadside Assistance Request Confirmed</h1>
            
            <div class="confirmation-box">
              <p>We have received your request for roadside assistance and are dispatching help to your location.</p>
              <p>Reference Number: <span class="reference-number">${t.referenceNumber}</span></p>
              <p>Request Time: ${n}</p>
            </div>
            
            <div class="request-details">
              <h2>Your Request Details</h2>
              <div class="detail-row">
                <div class="detail-label">Assistance Type:</div>
                <div class="detail-value">${t.assistanceType}</div>
              </div>
              <div class="detail-row">
                <div class="detail-label">Vehicle Model:</div>
                <div class="detail-value">${t.vehicleModel}</div>
              </div>
              <div class="detail-row">
                <div class="detail-label">Registration Number:</div>
                <div class="detail-value">${t.vehicleRegNumber}</div>
              </div>
              <div class="detail-row">
                <div class="detail-label">Location:</div>
                <div class="detail-value">${t.location}</div>
              </div>
            </div>
            
            <div class="assistance-steps">
              <h3>What Happens Next?</h3>
              <ol>
                <li>Our service team will call you within 15 minutes to confirm your request details.</li>
                <li>A qualified technician will be dispatched to your location. You will receive their estimated arrival time.</li>
                <li>The technician will assist with your ${t.assistanceType.toLowerCase()} or arrange for towing if necessary.</li>
                <li>For any status updates, please keep your reference number handy.</li>
              </ol>
            </div>
            
            <div class="tips-box">
              <h3>Safety Tips While Waiting</h3>
              <ul>
                <li>If possible, move your vehicle to a safe location away from traffic.</li>
                <li>Turn on your hazard lights to make your vehicle visible to other drivers.</li>
                <li>Stay inside your vehicle with doors locked if it's safe to do so.</li>
                <li>If you must exit your vehicle, do so from the passenger side, away from traffic.</li>
              </ul>
            </div>
            
            <div class="contact-info">
              <h3>Need Immediate Assistance?</h3>
              <p>If your situation is critical or you need to speak with someone immediately:</p>
              <a href="tel:01XXXXXXXXX" class="emergency-number">09639119977</a>
              <p>24/7 Emergency Hotline</p>
            </div>
          </div>
          <div class="footer">
            <p>Thank you for choosing Chery Bangladesh Roadside Assistance.</p>
            <p>Please do not reply to this email as it is automatically generated.</p>
            <p>&copy; ${new Date().getFullYear()} Chery Bangladesh. All rights reserved.</p>
          </div>
        </div>
      </body>
      </html>
    `)}),d.NextResponse.json({success:!0,message:"Your assistance request has been submitted! Our team will contact you shortly.",assistanceId:r._id,referenceNumber:s})}catch(e){return console.error("Error processing assistance request:",e),d.NextResponse.json({success:!1,message:"ValidationError"===e.name?"Invalid request data. Please check all fields and try again.":"Failed to process assistance request. Please call our emergency hotline directly."},{status:"ValidationError"===e.name?400:500})}}v||(v=global.mongoose={conn:null,promise:null});let f=new s.AppRouteRouteModule({definition:{kind:r.RouteKind.APP_ROUTE,page:"/api/roadside-assistance/route",pathname:"/api/roadside-assistance",filename:"route",bundlePath:"app/api/roadside-assistance/route"},resolvedPagePath:"D:\\Projects\\chery-bangladesh-nextjs\\src\\app\\api\\roadside-assistance\\route.js",nextConfigOutput:"export",userland:a}),{workAsyncStorage:y,workUnitAsyncStorage:x,serverHooks:b}=f;function w(){return(0,o.patchFetch)({workAsyncStorage:y,workUnitAsyncStorage:x})}},27910:e=>{"use strict";e.exports=require("stream")},28354:e=>{"use strict";e.exports=require("util")},29021:e=>{"use strict";e.exports=require("fs")},29294:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-async-storage.external.js")},33873:e=>{"use strict";e.exports=require("path")},34631:e=>{"use strict";e.exports=require("tls")},37366:e=>{"use strict";e.exports=require("dns")},44870:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},55511:e=>{"use strict";e.exports=require("crypto")},55591:e=>{"use strict";e.exports=require("https")},63033:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-unit-async-storage.external.js")},74075:e=>{"use strict";e.exports=require("zlib")},78335:()=>{},79551:e=>{"use strict";e.exports=require("url")},79646:e=>{"use strict";e.exports=require("child_process")},81630:e=>{"use strict";e.exports=require("http")},91645:e=>{"use strict";e.exports=require("net")},94735:e=>{"use strict";e.exports=require("events")},96487:()=>{}};var i=require("../../../webpack-runtime.js");i.C(e);var t=e=>i(i.s=e),a=i.X(0,[447,580,526],()=>t(26765));module.exports=a})();