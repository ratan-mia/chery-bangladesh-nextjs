(()=>{var e={};e.id=94,e.ids=[94],e.modules={3295:e=>{"use strict";e.exports=require("next/dist/server/app-render/after-task-async-storage.external.js")},10846:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},21820:e=>{"use strict";e.exports=require("os")},27910:e=>{"use strict";e.exports=require("stream")},28354:e=>{"use strict";e.exports=require("util")},29021:e=>{"use strict";e.exports=require("fs")},29294:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-async-storage.external.js")},33873:e=>{"use strict";e.exports=require("path")},34631:e=>{"use strict";e.exports=require("tls")},37366:e=>{"use strict";e.exports=require("dns")},44870:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},55511:e=>{"use strict";e.exports=require("crypto")},55591:e=>{"use strict";e.exports=require("https")},63033:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-unit-async-storage.external.js")},74075:e=>{"use strict";e.exports=require("zlib")},78335:()=>{},79551:e=>{"use strict";e.exports=require("url")},79646:e=>{"use strict";e.exports=require("child_process")},81630:e=>{"use strict";e.exports=require("http")},88255:(e,t,r)=>{"use strict";r.r(t),r.d(t,{patchFetch:()=>g,routeModule:()=>l,serverHooks:()=>u,workAsyncStorage:()=>p,workUnitAsyncStorage:()=>m});var o={};r.r(o),r.d(o,{POST:()=>d});var i=r(96559),a=r(48088),s=r(37719),n=r(32190),c=r(49526);async function d(e){try{let t=await e.json(),r=c.createTransport({service:"gmail",auth:{user:process.env.GMAIL_USER,pass:process.env.GMAIL_APP_PASSWORD}}),o=new Date(t.timestamp).toLocaleString("en-US",{year:"numeric",month:"long",day:"numeric",hour:"2-digit",minute:"2-digit",hour12:!0,timeZone:"Asia/Dhaka"}),i={tiggo4pro:"Tiggo 4 Pro",tiggo7pro:"Tiggo 7 Pro",tiggo8pro:"Tiggo 8 Pro",arrizo6:"Arrizo 6",omoda:"Omoda",jaccoo:"Jaccoo",other:"Other"},a={towing:"Vehicle Recovery/Towing","flat-tire":"Flat Tire",battery:"Battery Jump Start",fuel:"Fuel Delivery",lockout:"Lockout Assistance",other:"Other Emergency"},s={...t,formattedTimestamp:o,vehicleModelDisplay:i[t.vehicleModel]||t.vehicleModel,assistanceTypeDisplay:a[t.assistanceType]||t.assistanceType,requestId:function(){let e=new Date().getTime().toString(36),t=Math.random().toString(36).substring(2,7).toUpperCase();return`ER-${e}-${t}`}()};return await r.sendMail({from:`"Chery Emergency System" <${process.env.GMAIL_USER}>`,to:["info@cherybd.com","ratan.mia@continental-motor.com"],subject:`🚨 URGENT: Emergency Assistance Request - ${s.vehicleModelDisplay}`,html:`
  <!DOCTYPE html>
  <html>
  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Emergency Assistance Request</title>
    <style>
      body {
        font-family: Arial, sans-serif;
        line-height: 1.6;
        color: #333;
        margin: 0;
        padding: 0;
      }
      .container {
        max-width: 600px;
        margin: 0 auto;
        padding: 20px;
      }
      .header {
        background-color: #000000;
        color: #ffffff;
        padding: 20px;
        text-align: center;
        border-top: 5px solid #c20000;
      }
      .logo {
        max-width: 180px;
        margin-bottom: 15px;
      }
      .content {
        padding: 20px;
        background-color: #f9f9f9;
      }
      .emergency-alert {
        background-color: #c20000;
        color: white;
        padding: 10px 15px;
        font-weight: bold;
        text-align: center;
        margin-bottom: 20px;
      }
      .details {
        background-color: #ffffff;
        border: 1px solid #e0e0e0;
        padding: 15px;
        margin-bottom: 20px;
      }
      .details table {
        width: 100%;
        border-collapse: collapse;
      }
      .details table td {
        padding: 8px;
        border-bottom: 1px solid #e0e0e0;
      }
      .details table td:first-child {
        font-weight: bold;
        width: 40%;
      }
      .footer {
        font-size: 12px;
        text-align: center;
        margin-top: 20px;
        color: #666;
      }
      .button {
        display: inline-block;
        background-color: #c20000;
        color: #ffffff;
        padding: 12px 25px;
        text-decoration: none;
        font-weight: bold;
        border-radius: 4px;
        margin-top: 15px;
      }
      .timestamp {
        color: #666;
        font-size: 14px;
        margin-top: 15px;
        font-style: italic;
      }
      .location-map {
        width: 100%;
        max-width: 100%;
        height: auto;
        border: 1px solid #e0e0e0;
        margin-top: 10px;
      }
      .request-id {
        font-family: monospace;
        font-size: 16px;
        color: #c20000;
        font-weight: bold;
        margin-bottom: 10px;
        background-color: #f5f5f5;
        padding: 5px 10px;
        border-radius: 4px;
        display: inline-block;
      }
    </style>
  </head>
  <body>
    <div class="container">
      <div class="header">
        <img src="https://cherybd.com/logo.png" alt="Chery Bangladesh Logo" class="logo">
        <h1>Emergency Assistance Request</h1>
      </div>
      
      <div class="content">
        <div class="emergency-alert">
          IMMEDIATE ATTENTION REQUIRED
        </div>
        
        <div class="request-id">
          Request ID: ${s.requestId}
        </div>
        
        <p>A customer has requested emergency roadside assistance through the website. Please coordinate immediate support.</p>
        
        <div class="details">
          <h3>Request Details:</h3>
          <table>
            <tr>
              <td>Customer Name:</td>
              <td>${s.name}</td>
            </tr>
            <tr>
              <td>Contact Number:</td>
              <td>${s.contactNumber}</td>
            </tr>
            <tr>
              <td>Email Address:</td>
              <td>${s.email||"Not provided"}</td>
            </tr>
            <tr>
              <td>Vehicle Model:</td>
              <td>${s.vehicleModelDisplay}</td>
            </tr>
            <tr>
              <td>Registration Number:</td>
              <td>${s.vehicleRegNumber}</td>
            </tr>
            <tr>
              <td>Service Needed:</td>
              <td>${s.assistanceTypeDisplay}</td>
            </tr>
            <tr>
              <td>Current Location:</td>
              <td>${s.location}</td>
            </tr>
            ${s.description?`
            <tr>
              <td>Problem Description:</td>
              <td>${s.description}</td>
            </tr>
            `:""}
          </table>
        </div>
        
        <p>Please ensure immediate dispatch of the nearest available technician to the customer's location.</p>
        
        <div style="text-align: center;">
          <a href="https://admin.cherybd.com/emergencies/${s.requestId}" class="button">VIEW IN ADMIN DASHBOARD</a>
        </div>
        
        <p class="timestamp">Request received on: ${s.formattedTimestamp}</p>
        
        <!-- Map of customer location would go here in a real implementation -->
        <img src="https://maps.googleapis.com/maps/api/staticmap?center=${encodeURIComponent(s.location)}&zoom=14&size=600x300&markers=color:red%7C${encodeURIComponent(s.location)}&key=YOUR_API_KEY" alt="Customer Location Map" class="location-map">
      </div>
      
      <div class="footer">
        <p>This is an automated notification from the Chery Bangladesh emergency response system.</p>
        <p>\xa9 ${new Date().getFullYear()} Chery Bangladesh. All rights reserved.</p>
      </div>
    </div>
  </body>
  </html>
    `,priority:"high"}),t.email&&await r.sendMail({from:`"Chery Bangladesh Support" <${process.env.GMAIL_USER}>`,to:t.email,subject:"Your Emergency Assistance Request - Chery Bangladesh",html:`
  <!DOCTYPE html>
  <html>
  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Your Emergency Assistance Request - Chery Bangladesh</title>
    <style>
      body {
        font-family: Arial, sans-serif;
        line-height: 1.6;
        color: #333;
        margin: 0;
        padding: 0;
      }
      .container {
        max-width: 600px;
        margin: 0 auto;
        padding: 20px;
      }
      .header {
        background-color: #000000;
        color: #ffffff;
        padding: 20px;
        text-align: center;
        border-top: 5px solid #c20000;
      }
      .logo {
        max-width: 180px;
        margin-bottom: 15px;
      }
      .content {
        padding: 20px;
        background-color: #f9f9f9;
      }
      .confirmation-box {
        background-color: #4CAF50;
        color: white;
        padding: 10px 15px;
        font-weight: bold;
        text-align: center;
        margin-bottom: 20px;
        border-radius: 4px;
      }
      .details {
        background-color: #ffffff;
        border: 1px solid #e0e0e0;
        padding: 15px;
        margin-bottom: 20px;
      }
      .details table {
        width: 100%;
        border-collapse: collapse;
      }
      .details table td {
        padding: 8px;
        border-bottom: 1px solid #e0e0e0;
      }
      .details table td:first-child {
        font-weight: bold;
        width: 40%;
      }
      .what-next {
        background-color: #f5f5f5;
        border-left: 4px solid #c20000;
        padding: 15px;
        margin-bottom: 20px;
      }
      .contact-info {
        background-color: #ffffff;
        border: 1px solid #e0e0e0;
        padding: 15px;
        margin-top: 20px;
        text-align: center;
      }
      .contact-info h3 {
        margin-top: 0;
        color: #c20000;
      }
      .contact-number {
        font-size: 24px;
        font-weight: bold;
        color: #c20000;
        margin: 10px 0;
      }
      .footer {
        font-size: 12px;
        text-align: center;
        margin-top: 20px;
        color: #666;
      }
      .social-links {
        margin-top: 15px;
      }
      .social-links a {
        display: inline-block;
        margin: 0 5px;
        color: #666;
        text-decoration: none;
      }
      .social-links a:hover {
        color: #c20000;
      }
      .app-promo {
        margin-top: 20px;
        padding: 15px;
        background-color: #f0f0f0;
        border-radius: 4px;
        text-align: center;
      }
      .app-buttons {
        margin-top: 10px;
      }
      .app-buttons img {
        height: 40px;
        margin: 0 5px;
      }
      .request-id {
        font-family: monospace;
        font-size: 14px;
        color: #666;
        margin-bottom: 10px;
      }
    </style>
  </head>
  <body>
    <div class="container">
      <div class="header">
        <img src="https://cherybd.com/logo.png" alt="Chery Bangladesh Logo" class="logo">
        <h1>Emergency Assistance Confirmation</h1>
      </div>
      
      <div class="content">
        <div class="confirmation-box">
          YOUR REQUEST HAS BEEN RECEIVED
        </div>
        
        <p>Dear ${s.name},</p>
        
        <p>We have received your emergency assistance request and our team has been notified. A Chery certified technician will contact you shortly to provide assistance.</p>
        
        <div class="request-id">Reference Number: ${s.requestId}</div>
        
        <div class="details">
          <h3>Your Request Details:</h3>
          <table>
            <tr>
              <td>Request Time:</td>
              <td>${s.formattedTimestamp}</td>
            </tr>
            <tr>
              <td>Vehicle Model:</td>
              <td>${s.vehicleModelDisplay}</td>
            </tr>
            <tr>
              <td>Registration Number:</td>
              <td>${s.vehicleRegNumber}</td>
            </tr>
            <tr>
              <td>Assistance Type:</td>
              <td>${s.assistanceTypeDisplay}</td>
            </tr>
            <tr>
              <td>Your Location:</td>
              <td>${s.location}</td>
            </tr>
            ${s.description?`
            <tr>
              <td>Problem Description:</td>
              <td>${s.description}</td>
            </tr>
            `:""}
          </table>
        </div>
        
        <div class="what-next">
          <h3>What happens next?</h3>
          <ol>
            <li>Our emergency team will call you at <strong>${s.contactNumber}</strong> within 5-10 minutes</li>
            <li>A certified technician will be dispatched to your location</li>
            <li>You'll receive updates on the technician's arrival time</li>
          </ol>
        </div>
        
        <p>For faster assistance, you can also directly call our 24/7 emergency support line.</p>
        
        <div class="contact-info">
          <h3>24/7 EMERGENCY SUPPORT</h3>
          <div class="contact-number">09639119977</div>
          <p>Available 24 hours a day, 7 days a week</p>
        </div>
        
        <div class="app-promo">
          <h3>Download Chery Bangladesh App</h3>
          <p>For easier emergency assistance and service booking in the future</p>
          <div class="app-buttons">
            <a href="#"><img src="https://cherybd.com/images/app-store.png" alt="App Store"></a>
            <a href="#"><img src="https://cherybd.com/images/play-store.png" alt="Play Store"></a>
          </div>
        </div>
      </div>
      
      <div class="footer">
        <p>Thank you for choosing Chery Bangladesh.</p>
        <p>If you have any questions, please contact our customer service at info@cherybd.com</p>
        
        <div class="social-links">
          <a href="https://facebook.com/cherybd">Facebook</a> |
          <a href="https://instagram.com/cherybd">Instagram</a> |
          <a href="https://youtube.com/cherybd">YouTube</a>
        </div>
        
        <p>\xa9 ${new Date().getFullYear()} Chery Bangladesh. All rights reserved.</p>
      </div>
    </div>
  </body>
  </html>
    `}),console.log("Emergency assistance request received:",{timestamp:o,name:t.name,location:t.location,vehicleModel:i[t.vehicleModel]||t.vehicleModel,assistanceType:a[t.assistanceType]||t.assistanceType}),n.NextResponse.json({success:!0,message:"Emergency assistance request received. Our team will contact you shortly."})}catch(e){return console.error("Error processing emergency request:",e),n.NextResponse.json({success:!1,message:"Failed to process emergency assistance request"},{status:500})}}let l=new i.AppRouteRouteModule({definition:{kind:a.RouteKind.APP_ROUTE,page:"/api/emergency-assistance/route",pathname:"/api/emergency-assistance",filename:"route",bundlePath:"app/api/emergency-assistance/route"},resolvedPagePath:"D:\\Projects\\chery-bangladesh-nextjs\\src\\app\\api\\emergency-assistance\\route.js",nextConfigOutput:"export",userland:o}),{workAsyncStorage:p,workUnitAsyncStorage:m,serverHooks:u}=l;function g(){return(0,s.patchFetch)({workAsyncStorage:p,workUnitAsyncStorage:m})}},91645:e=>{"use strict";e.exports=require("net")},94735:e=>{"use strict";e.exports=require("events")},96487:()=>{}};var t=require("../../../webpack-runtime.js");t.C(e);var r=e=>t(t.s=e),o=t.X(0,[447,580,526],()=>r(88255));module.exports=o})();