(()=>{var e={};e.id=309,e.ids=[309],e.modules={3295:e=>{"use strict";e.exports=require("next/dist/server/app-render/after-task-async-storage.external.js")},10846:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},21820:e=>{"use strict";e.exports=require("os")},27910:e=>{"use strict";e.exports=require("stream")},28354:e=>{"use strict";e.exports=require("util")},29021:e=>{"use strict";e.exports=require("fs")},29294:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-async-storage.external.js")},33873:e=>{"use strict";e.exports=require("path")},34631:e=>{"use strict";e.exports=require("tls")},37366:e=>{"use strict";e.exports=require("dns")},44870:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},45008:(e,t,r)=>{"use strict";r.r(t),r.d(t,{patchFetch:()=>A,routeModule:()=>b,serverHooks:()=>y,workAsyncStorage:()=>v,workUnitAsyncStorage:()=>w});var a={};r.r(a),r.d(a,{POST:()=>x});var i=r(96559),s=r(48088),o=r(37719),n=r(55511),p=r(29021),d=r.n(p);let c=require("fs/promises");var l=r(32190),u=r(49526),h=r(33873),m=r.n(h);async function g(e){let t=await e.formData(),r={};for(let[e,a]of t.entries())"resume"!==e&&(r[e]=a);return{formData:r,file:t.get("resume")}}async function f(e){let t=m().join(process.cwd(),"tmp");try{await d().promises.mkdir(t,{recursive:!0})}catch(e){console.error("Error creating temp directory:",e)}let r=`${(0,n.randomUUID)()}-${e.name}`,a=m().join(t,r),i=await e.arrayBuffer(),s=Buffer.from(i);return await (0,c.writeFile)(a,s),{filepath:a,originalFilename:e.name}}async function x(e){try{let{formData:t,file:r}=await g(e);if(!t.name||!t.email||!t.phone||!t.department||!r)return l.NextResponse.json({success:!1,error:"Missing required fields"},{status:400});let{filepath:a,originalFilename:i}=await f(r),s=u.createTransport({service:"gmail",auth:{user:process.env.GMAIL_USER,pass:process.env.GMAIL_APP_PASSWORD}}),o={sales:"Sales",service:"Service & After-Sales",marketing:"Marketing",admin:"Administration",parts:"Parts & Logistics",other:"Other Department"}[t.department]||"Unspecified Department",n=d().readFileSync(a),p={from:process.env.GMAIL_USER,to:"hr@cherybd.com",subject:`New Job Application: ${t.name} - ${o}`,html:`
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>New Job Application</title>
  <style>
    body { 
      font-family: Arial, sans-serif; 
      line-height: 1.6;
      color: #333333;
      margin: 0;
      padding: 0;
    }
    .container {
      max-width: 600px;
      margin: 0 auto;
      padding: 20px;
      border: 1px solid #e0e0e0;
    }
    .header {
      background-color: #8B0000;
      padding: 20px;
      text-align: center;
      color: white;
    }
    .content {
      padding: 20px;
      background-color: #ffffff;
    }
    .footer {
      background-color: #f5f5f5;
      padding: 15px;
      text-align: center;
      font-size: 12px;
      color: #666666;
    }
    table {
      width: 100%;
      border-collapse: collapse;
      margin-bottom: 20px;
    }
    th, td {
      border: 1px solid #e0e0e0;
      padding: 10px;
      text-align: left;
    }
    th {
      background-color: #f5f5f5;
    }
    .message-box {
      background-color: #f9f9f9;
      padding: 15px;
      border-radius: 5px;
      margin-bottom: 20px;
    }
  </style>
</head>
<body>
  <div class="container">
    <div class="header">
      <h1>New Job Application Received</h1>
    </div>
    <div class="content">
      <p>A new application has been submitted through the Chery Bangladesh careers page.</p>
      
      <table>
        <tr>
          <th>Field</th>
          <th>Information</th>
        </tr>
        <tr>
          <td>Name</td>
          <td>${t.name}</td>
        </tr>
        <tr>
          <td>Email</td>
          <td>${t.email}</td>
        </tr>
        <tr>
          <td>Phone</td>
          <td>${t.phone}</td>
        </tr>
        <tr>
          <td>Department</td>
          <td>${t.department}</td>
        </tr>
      </table>
      
      <h3>Cover Letter/Additional Information:</h3>
      <div class="message-box">
        ${t.message?t.message.replace(/\n/g,"<br>"):"No additional information provided."}
      </div>
      
      <p>Please find the applicant's resume attached to this email.</p>
      <p>This application was received on ${new Date().toLocaleString()}.</p>
    </div>
    <div class="footer">
      <p>This is an automated message from the Chery Bangladesh website.</p>
      <p>&copy; ${new Date().getFullYear()} Chery Bangladesh. All rights reserved.</p>
    </div>
  </div>
</body>
</html>
  `,attachments:[{filename:i,content:n}]},c={from:process.env.GMAIL_USER,to:"ratan.mia@continental-motor.com",subject:`New Applicant Alert: ${t.name} for ${o}`,html:`
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>New Job Application Notification</title>
  <style>
    body { 
      font-family: Arial, sans-serif; 
      line-height: 1.6;
      color: #333333;
      margin: 0;
      padding: 0;
    }
    .container {
      max-width: 600px;
      margin: 0 auto;
      padding: 20px;
      border: 1px solid #e0e0e0;
    }
    .header {
      background-color: #8B0000;
      padding: 20px;
      text-align: center;
      color: white;
    }
    .content {
      padding: 20px;
      background-color: #ffffff;
    }
    .footer {
      background-color: #f5f5f5;
      padding: 15px;
      text-align: center;
      font-size: 12px;
      color: #666666;
    }
    .highlight {
      background-color: #ffeb3b;
      padding: 2px 5px;
      font-weight: bold;
    }
    .applicant-info {
      background-color: #f9f9f9;
      padding: 15px;
      border-radius: 5px;
      margin-bottom: 20px;
    }
    .button {
      display: inline-block;
      background-color: #8B0000;
      color: white;
      padding: 10px 20px;
      text-decoration: none;
      border-radius: 5px;
      margin-top: 10px;
    }
  </style>
</head>
<body>
  <div class="container">
    <div class="header">
      <h1>New Application Alert</h1>
    </div>
    <div class="content">
      <p>Dear Manager,</p>
      
      <p>A new candidate has applied for the <span class="highlight">${t.department}</span> department.</p>
      
      <div class="applicant-info">
        <p><strong>Applicant:</strong> ${t.name}</p>
        <p><strong>Contact:</strong> ${t.email} | ${t.phone}</p>
      </div>
      
      <p>The complete application details and resume have been sent to the HR department.</p>
      
      <p>Please coordinate with HR if you would like to schedule an interview with this candidate.</p>
      
      <p>This application was received on ${new Date().toLocaleString()}.</p>
      
      <a href="mailto:${t.email}" class="button">Contact Applicant</a>
    </div>
    <div class="footer">
      <p>This is an automated message from the Chery Bangladesh website.</p>
      <p>&copy; ${new Date().getFullYear()} Chery Bangladesh. All rights reserved.</p>
    </div>
  </div>
</body>
</html>
  `,attachments:[{filename:i,content:n}]};return await s.sendMail(p),await s.sendMail(c),d().unlinkSync(a),l.NextResponse.json({success:!0,message:"Application submitted successfully"})}catch(e){return console.error("Error processing application:",e),l.NextResponse.json({success:!1,error:"Failed to process application"},{status:500})}}let b=new i.AppRouteRouteModule({definition:{kind:s.RouteKind.APP_ROUTE,page:"/api/send-application/route",pathname:"/api/send-application",filename:"route",bundlePath:"app/api/send-application/route"},resolvedPagePath:"D:\\Projects\\chery-bangladesh-nextjs\\src\\app\\api\\send-application\\route.js",nextConfigOutput:"export",userland:a}),{workAsyncStorage:v,workUnitAsyncStorage:w,serverHooks:y}=b;function A(){return(0,o.patchFetch)({workAsyncStorage:v,workUnitAsyncStorage:w})}},55511:e=>{"use strict";e.exports=require("crypto")},55591:e=>{"use strict";e.exports=require("https")},63033:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-unit-async-storage.external.js")},74075:e=>{"use strict";e.exports=require("zlib")},78335:()=>{},79551:e=>{"use strict";e.exports=require("url")},79646:e=>{"use strict";e.exports=require("child_process")},81630:e=>{"use strict";e.exports=require("http")},91645:e=>{"use strict";e.exports=require("net")},94735:e=>{"use strict";e.exports=require("events")},96487:()=>{}};var t=require("../../../webpack-runtime.js");t.C(e);var r=e=>t(t.s=e),a=t.X(0,[447,580,526],()=>r(45008));module.exports=a})();