(()=>{var e={};e.id=997,e.ids=[997],e.modules={3295:e=>{"use strict";e.exports=require("next/dist/server/app-render/after-task-async-storage.external.js")},10846:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},21820:e=>{"use strict";e.exports=require("os")},25236:(e,i,s)=>{"use strict";s.r(i),s.d(i,{patchFetch:()=>m,routeModule:()=>g,serverHooks:()=>v,workAsyncStorage:()=>h,workUnitAsyncStorage:()=>u});var o={};s.r(o),s.d(o,{POST:()=>p});var t=s(96559),a=s(48088),r=s(37719),n=s(32190),l=s(49526);let d=e=>`
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>New Test Drive Booking</title>
        <style>
          body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            color: #333333;
            margin: 0;
            padding: 0;
          }
          .container {
            max-width: 600px;
            margin: 0 auto;
            padding: 20px;
          }
          .header {
            background-color: #524336;
            padding: 20px;
            text-align: center;
          }
          .header h1 {
            color: white;
            margin: 0;
            font-size: 24px;
          }
          .content {
            padding: 20px;
            background-color: #ffffff;
          }
          .booking-info {
            background-color: #f9f9f9;
            border-left: 4px solid #8c735d;
            padding: 15px;
            margin-bottom: 20px;
          }
          .booking-detail {
            margin-bottom: 10px;
          }
          .label {
            font-weight: bold;
            width: 150px;
            display: inline-block;
          }
          .value {
            display: inline-block;
          }
          .footer {
            text-align: center;
            padding: 20px;
            font-size: 12px;
            color: #666666;
            background-color: #f3f3f3;
          }
          .logo {
            margin-bottom: 20px;
          }
          .note {
            background-color: #fff8e1;
            padding: 15px;
            border-radius: 4px;
            margin-top: 20px;
            border-left: 4px solid #ffc107;
          }
          .button {
            display: inline-block;
            background-color: #8c735d;
            color: white;
            text-decoration: none;
            padding: 10px 20px;
            border-radius: 4px;
            margin-top: 15px;
          }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="header">
            <img src="https://www.cherybd.com/images/logo-white.png" alt="Chery Bangladesh" height="40" class="logo">
            <h1>New Test Drive Booking</h1>
          </div>
          <div class="content">
            <p>Dear Admin,</p>
            <p>A new test drive has been booked through the website. Please find the details below:</p>
            
            <div class="booking-info">
              <div class="booking-detail">
                <span class="label">Booking ID:</span>
                <span class="value">${e.bookingId}</span>
              </div>
              <div class="booking-detail">
                <span class="label">Booking Date:</span>
                <span class="value">${e.bookingDate}</span>
              </div>
              <div class="booking-detail">
                <span class="label">Vehicle Model:</span>
                <span class="value">${e.vehicleModel}</span>
              </div>
              <div class="booking-detail">
                <span class="label">Customer Name:</span>
                <span class="value">${e.name}</span>
              </div>
              <div class="booking-detail">
                <span class="label">Contact Number:</span>
                <span class="value">${e.contactNumber}</span>
              </div>
              <div class="booking-detail">
                <span class="label">Email:</span>
                <span class="value">${e.email}</span>
              </div>
              <div class="booking-detail">
                <span class="label">Preferred Date:</span>
                <span class="value">${e.preferredDate}</span>
              </div>
              <div class="booking-detail">
                <span class="label">Preferred Time:</span>
                <span class="value">${e.preferredTime}</span>
              </div>
              <div class="booking-detail">
                <span class="label">Location:</span>
                <span class="value">${e.location}</span>
              </div>
              <div class="booking-detail">
                <span class="label">Driving Experience:</span>
                <span class="value">${e.drivingExperience}</span>
              </div>
              <div class="booking-detail">
                <span class="label">Special Requests:</span>
                <span class="value">${e.specificRequests}</span>
              </div>
            </div>
            
            <div class="note">
              <p><strong>Please Note:</strong> The customer is expecting confirmation within 24 hours. Please confirm this booking by contacting the customer as soon as possible.</p>
            </div>
            
            <a href="https://admin.cherybd.com/test-drive-bookings" class="button">View in Admin Dashboard</a>
          </div>
          <div class="footer">
            <p>&copy; ${new Date().getFullYear()} Chery Bangladesh. All rights reserved.</p>
            <p>Continental Motors Ltd. | Authorized Distributor of Chery Automobile in Bangladesh</p>
          </div>
        </div>
      </body>
      </html>
    `,c=e=>`
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Your Test Drive Booking Confirmation</title>
        <style>
          body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            color: #333333;
            margin: 0;
            padding: 0;
          }
          .container {
            max-width: 600px;
            margin: 0 auto;
            padding: 20px;
          }
          .header {
            background-color: #524336;
            padding: 20px;
            text-align: center;
          }
          .header h1 {
            color: white;
            margin: 0;
            font-size: 24px;
          }
          .subheader {
            background-color: #8c735d;
            color: white;
            padding: 10px 20px;
            text-align: center;
          }
          .content {
            padding: 20px;
            background-color: #ffffff;
          }
          .booking-info {
            background-color: #f9f9f9;
            border-left: 4px solid #8c735d;
            padding: 15px;
            margin: 20px 0;
          }
          .booking-detail {
            margin-bottom: 10px;
          }
          .label {
            font-weight: bold;
            min-width: 150px;
            display: inline-block;
          }
          .value {
            display: inline-block;
          }
          .footer {
            text-align: center;
            padding: 20px;
            font-size: 12px;
            color: #666666;
            background-color: #f3f3f3;
          }
          .logo {
            margin-bottom: 20px;
          }
          .info-section {
            background-color: #f5f5f5;
            padding: 15px;
            margin-top: 20px;
          }
          .info-section h3 {
            margin-top: 0;
            color: #524336;
            border-bottom: 2px solid #8c735d;
            padding-bottom: 5px;
            display: inline-block;
          }
          .info-item {
            display: flex;
            margin-bottom: 10px;
          }
          .info-icon {
            margin-right: 10px;
            color: #8c735d;
            font-weight: bold;
          }
          .button {
            display: inline-block;
            background-color: #8c735d;
            color: white;
            text-decoration: none;
            padding: 10px 20px;
            border-radius: 4px;
            margin-top: 15px;
          }
          .highlight {
            color: #524336;
            font-weight: bold;
          }
          .banner {
            width: 100%;
            max-width: 600px;
            height: auto;
            margin-bottom: 20px;
          }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="header">
            <img src="https://www.cherybd.com/images/logo-white.png" alt="Chery Bangladesh" height="40" class="logo">
            <h1>Test Drive Booking Confirmation</h1>
          </div>
          <div class="subheader">
            Thank you for choosing Chery Bangladesh!
          </div>
          <div class="content">
            <img src="https://www.cherybd.com/images/test-drive-banner.jpg" alt="Test Drive Experience" class="banner">
          
            <p>Dear <span class="highlight">${e.name}</span>,</p>
            
            <p>Thank you for booking a test drive with Chery Bangladesh. We're excited to have you experience the exceptional performance and comfort of the <span class="highlight">${e.vehicleModel}</span>.</p>
            
            <p>Your test drive request has been received and is being processed. A member of our team will contact you within 24 hours to confirm your appointment.</p>
            
            <div class="booking-info">
              <div class="booking-detail">
                <span class="label">Booking Reference:</span>
                <span class="value">${e.bookingId}</span>
              </div>
              <div class="booking-detail">
                <span class="label">Vehicle Model:</span>
                <span class="value">${e.vehicleModel}</span>
              </div>
              <div class="booking-detail">
                <span class="label">Preferred Date:</span>
                <span class="value">${e.preferredDate}</span>
              </div>
              <div class="booking-detail">
                <span class="label">Preferred Time:</span>
                <span class="value">${e.preferredTime}</span>
              </div>
              <div class="booking-detail">
                <span class="label">Dealership Location:</span>
                <span class="value">${e.location}</span>
              </div>
            </div>
            
            <div class="info-section">
              <h3>What to Bring</h3>
              <div class="info-item">
                <div class="info-icon">→</div>
                <div>Valid driving license</div>
              </div>
              <div class="info-item">
                <div class="info-icon">→</div>
                <div>National ID card</div>
              </div>
              <div class="info-item">
                <div class="info-icon">→</div>
                <div>A copy of this confirmation email</div>
              </div>
            </div>
            
            <div class="info-section">
              <h3>Test Drive Experience</h3>
              <p>Your test drive will last approximately 30-45 minutes, during which our product specialist will guide you through the vehicle's features and capabilities. You'll have the opportunity to experience the vehicle on both urban roads and highways near the dealership.</p>
            </div>
            
            <p>If you need to reschedule or cancel your test drive, or if you have any questions, please contact us at <a href="tel:09639119977">09639119977</a> or reply to this email.</p>
            
            <a href="https://www.cherybd.com/vehicles/${e.vehicleModel.toLowerCase()}" class="button">Learn More About ${e.vehicleModel}</a>
          </div>
          <div class="footer">
            <p>&copy; ${new Date().getFullYear()} Chery Bangladesh. All rights reserved.</p>
            <p>Continental Motors Ltd. | Authorized Distributor of Chery Automobile in Bangladesh</p>
            <p>
              <a href="https://www.cherybd.com/privacy-policy">Privacy Policy</a> | 
              <a href="https://www.cherybd.com/terms-conditions">Terms & Conditions</a>
            </p>
          </div>
        </div>
      </body>
      </html>
    `;async function p(e){try{let{vehicleModel:i,preferredDate:s,preferredTime:o,location:t,contactNumber:a,name:r,email:p,drivingExperience:g,specificRequests:h}=await e.json(),u={sender:{name:"Chery Bangladesh",email:process.env.GMAIL_USER},adminRecipients:["info@cherybd.com","ratan.mia@continental-motor.com"],subjects:{testDriveAdmin:"New Test Drive Booking - Chery Bangladesh",testDriveCustomer:"Your Chery Test Drive Booking Confirmation"}},v=l.createTransport({service:"gmail",host:"smtp.gmail.com",port:587,secure:!1,auth:{user:process.env.GMAIL_USER,pass:process.env.GMAIL_APP_PASSWORD}}),m=new Date(s).toLocaleDateString("en-US",{year:"numeric",month:"long",day:"numeric"}),b={tiggo4pro:"Tiggo 4 Pro",tiggo7pro:"Tiggo 7 Pro",tiggo8pro:"Tiggo 8 Pro",arrizo6:"Arrizo 6",omoda:"Omoda",jaccoo:"Jaccoo"}[i]||i,f={name:r,email:p,contactNumber:a,vehicleModel:b,preferredDate:m,preferredTime:o,location:t,drivingExperience:g||"Not specified",specificRequests:h||"None",bookingId:`TD-${Date.now().toString().slice(-6)}`,bookingDate:new Date().toLocaleDateString("en-US",{year:"numeric",month:"long",day:"numeric"})};return await v.sendMail({from:`"${u.sender.name}" <${u.sender.email}>`,to:u.adminRecipients,subject:`${u.subjects.testDriveAdmin} - ${b}`,html:d(f)}),await v.sendMail({from:`"${u.sender.name}" <${u.sender.email}>`,to:p,subject:u.subjects.testDriveCustomer,html:c(f)}),n.NextResponse.json({success:!0,message:"Test drive booking submitted successfully"})}catch(e){return console.error("Error processing test drive booking:",e),n.NextResponse.json({success:!1,message:"Failed to process your booking request"},{status:500})}}let g=new t.AppRouteRouteModule({definition:{kind:a.RouteKind.APP_ROUTE,page:"/api/test-drive/route",pathname:"/api/test-drive",filename:"route",bundlePath:"app/api/test-drive/route"},resolvedPagePath:"D:\\Projects\\chery-bangladesh-nextjs\\src\\app\\api\\test-drive\\route.js",nextConfigOutput:"export",userland:o}),{workAsyncStorage:h,workUnitAsyncStorage:u,serverHooks:v}=g;function m(){return(0,r.patchFetch)({workAsyncStorage:h,workUnitAsyncStorage:u})}},27910:e=>{"use strict";e.exports=require("stream")},28354:e=>{"use strict";e.exports=require("util")},29021:e=>{"use strict";e.exports=require("fs")},29294:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-async-storage.external.js")},33873:e=>{"use strict";e.exports=require("path")},34631:e=>{"use strict";e.exports=require("tls")},37366:e=>{"use strict";e.exports=require("dns")},44870:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},55511:e=>{"use strict";e.exports=require("crypto")},55591:e=>{"use strict";e.exports=require("https")},63033:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-unit-async-storage.external.js")},74075:e=>{"use strict";e.exports=require("zlib")},78335:()=>{},79551:e=>{"use strict";e.exports=require("url")},79646:e=>{"use strict";e.exports=require("child_process")},81630:e=>{"use strict";e.exports=require("http")},91645:e=>{"use strict";e.exports=require("net")},94735:e=>{"use strict";e.exports=require("events")},96487:()=>{}};var i=require("../../../webpack-runtime.js");i.C(e);var s=e=>i(i.s=e),o=i.X(0,[447,580,526],()=>s(25236));module.exports=o})();